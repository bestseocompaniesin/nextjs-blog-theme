import Link from 'next/link';

export default function Header({ name }) {
  return (
    <header className="pt-20 pb-12">
    <meta name="ahrefs-site-verification" content="02b2843411de6780bb9d5c0856d3ee71f09499a2bf42efba9db16dc742a88fa3"></meta>
      <div className="w-12 h-12 rounded-full block mx-auto mb-4 bg-gradient-conic from-gradient-3 to-gradient-4" />
      <p className="text-2xl dark:text-white text-center">
        <Link href="/">
          <a>{name}</a>
        </Link>
      </p>
    </header>
  );
}
